# FlagsQuiz (Bandiere del Mondo)

App Android in Jetpack Compose con quiz delle bandiere.

## Build

1. Apri la cartella in Android Studio (JDK 17+).
2. Sincronizza Gradle e avvia su dispositivo/emulatore API 24+.

## Ads di test
- Banner: `ca-app-pub-3940256099942544/9214589741`
- Interstitial: `ca-app-pub-3940256099942544/1033173712`
- Rewarded: `ca-app-pub-3940256099942544/5354046379`

## Dati
- `app/src/main/assets/countries.json`: elenco paesi con codice ISO2 e nome inglese
- `app/src/main/assets/flags/*.png`: bandiere

Per scaricare tutte le bandiere e generare `countries.json`:
```bash
./scripts/fetch_flags.sh
```
Richiede `jq` installato.

## Traduzioni
- Traduzione runtime tramite ML Kit Translate nella lingua del dispositivo o scelta dal menu Lingua.

## Suoni
- Sostituisci `res/raw/correct.mp3` e `res/raw/wrong.mp3` con effetti brevi liberi.

## Note licenze
- Bandiere PNG da Flagpedia/FlagCDN (pubblico dominio). Verifica policy aggiornata.

��#   P r o g e t t o   B a n d i e r e 
 
 